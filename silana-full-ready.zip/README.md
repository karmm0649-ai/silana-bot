
# Silana Lite WhatsApp Bot

## التشغيل
- Docker: Node.js 18
- Startup:
  npm install && node test.js

## الربط
- أول تشغيل هيظهر QR
- اعمل Scan مرة واحدة
- الجلسة بتتحفظ في sessions/

## الذكاء الاصطناعي
- ضيف Environment Variable:
  OPENAI_API_KEY=your_key_here

## أوامر
- 1 أو xo : لعبة XO
- ai سؤالك : ذكاء اصطناعي
- الاوامر : قائمة الأوامر

## 24/7
- سيب السيرفر شغال
- متحذفش فولدر sessions
